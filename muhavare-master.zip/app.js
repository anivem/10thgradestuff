// Data
const muhavareData = {
  categories: [
    {
      name: "आँख (Eye)",
      emoji: "👁️",
      muhavare: [
        { id: 1, hindi: "दाल न गलना", meaning_hindi: "कोई प्रभाव न पड़ना, बेकार होना", meaning_english: "No effect, useless", example: "मैं कितना भी समझाता हूँ पर उसकी दाल नहीं गलती।", difficulty: "easy" },
        { id: 2, hindi: "आँखें खुल जाना", meaning_hindi: "समझ में आ जाना, होश आना", meaning_english: "To understand, to realize", example: "उस घटना के बाद रामू की आँखें खुल गईं।", difficulty: "easy" },
        { id: 3, hindi: "आँखें चुराना", meaning_hindi: "शर्माना, पहचान से बचना", meaning_english: "To shy away, to avoid", example: "अपराधी पुलिस से आँखें चुरा रहा था।", difficulty: "easy" },
        { id: 4, hindi: "आँख का तारा", meaning_hindi: "बहुत प्रिय, सबसे पसंदीदा", meaning_english: "Beloved, favorite", example: "बेटा पिता की आँख का तारा है।", difficulty: "easy" },
        { id: 5, hindi: "आँख का काँटा", meaning_hindi: "बहुत बड़ा दुश्मन", meaning_english: "Big enemy", example: "शक्तिमान उसकी आँख का काँटा है।", difficulty: "easy" },
        { id: 6, hindi: "आँखें फोड़कर पढ़ना", meaning_hindi: "बहुत ध्यान से पढ़ना, कड़ी मेहनत", meaning_english: "Study hard", example: "परीक्षा पास करने के लिए आँखें फोड़कर पढ़ना होगा।", difficulty: "medium" }
      ]
    },
    {
      name: "हाथ (Hand)",
      emoji: "✋",
      muhavare: [
        { id: 7, hindi: "हाथ आना", meaning_hindi: "अवसर मिलना, नियंत्रण में आना", meaning_english: "Get opportunity", example: "जब दुश्मन हाथ आया तो उसे सजा दी गई।", difficulty: "easy" },
        { id: 8, hindi: "हाथ धोना", meaning_hindi: "किसी से पूरी तरह नाता तोड़ना", meaning_english: "Cut all ties", example: "बेईमान दोस्त से मैंने हाथ धो लिए।", difficulty: "easy" },
        { id: 9, hindi: "हाथ मलना", meaning_hindi: "खेद, पछतावा व्यक्त करना", meaning_english: "Regret, repent", example: "परीक्षा में असफल होकर छात्र हाथ मलते रह गए।", difficulty: "medium" },
        { id: 10, hindi: "जान तोड़ मेहनत", meaning_hindi: "कड़ी मेहनत, परिश्रम करना", meaning_english: "Hard work", example: "मैच जीतने के लिए सभी ने जान तोड़ मेहनत की।", difficulty: "medium" },
        { id: 11, hindi: "आड़े हाथों लेना", meaning_hindi: "कठोर व्यवहार करना, सजा देना", meaning_english: "Harsh treatment", example: "उसके बुरे व्यवहार के कारण उसे आड़े हाथों लिया गया।", difficulty: "hard" }
      ]
    },
    {
      name: "दिल (Heart)",
      emoji: "❤️",
      muhavare: [
        { id: 12, hindi: "दिल टूटना", meaning_hindi: "बहुत निराश होना", meaning_english: "Disappointed, sad", example: "असफलता के कारण उसका दिल टूट गया।", difficulty: "easy" },
        { id: 13, hindi: "कलेजा ठंडा होना", meaning_hindi: "संतुष्ट होना, खुश होना", meaning_english: "Satisfied, happy", example: "बेटे की सफलता से माता-पिता का कलेजा ठंडा हो गया।", difficulty: "easy" },
        { id: 14, hindi: "कलेजा मुँह में आना", meaning_hindi: "डर के मारे बुरी हालत होना", meaning_english: "Fear-struck", example: "सिंह को देखकर हिरन का कलेजा मुँह में आ गया।", difficulty: "medium" },
        { id: 15, hindi: "कलेजा फटना", meaning_hindi: "असहनीय दुःख होना", meaning_english: "Unbearable sorrow", example: "बेटी की मृत्यु से माता का कलेजा फट गया।", difficulty: "hard" }
      ]
    },
    {
      name: "सिर (Head)",
      emoji: "🤯",
      muhavare: [
        { id: 16, hindi: "सिर पर कफन बाँधना", meaning_hindi: "मृत्यु के लिए तैयार होना, बहुत खतरा मोल लेना", meaning_english: "Ready to die, face extreme danger", example: "शहीदों ने सिर पर कफन बाँधकर देश की रक्षा की।", difficulty: "easy" },
        { id: 17, hindi: "सिर चढ़ जाना", meaning_hindi: "अहंकार से भर जाना, शरारत करना", meaning_english: "Arrogance, mischief", example: "जीत मिलते ही उसे सींग चढ़ गया।", difficulty: "medium" },
        { id: 18, hindi: "कमर कसना", meaning_hindi: "तैयार होना, संकल्पबद्ध होना", meaning_english: "Get ready, prepare", example: "कक्षा में अच्छे नंबर लाने के लिए छात्रों ने कमर कस ली।", difficulty: "easy" }
      ]
    },
    {
      name: "मुँह (Mouth)",
      emoji: "👄",
      muhavare: [
        { id: 19, hindi: "मुँह काला करना", meaning_hindi: "अपमान, शर्मिंदगी होना", meaning_english: "Shame, disgrace", example: "परीक्षा में चोरी पकड़ी जाने से उसका मुँह काला हो गया।", difficulty: "easy" },
        { id: 20, hindi: "मुँह खोलना", meaning_hindi: "कुछ कहना, बोलना", meaning_english: "To speak, say something", example: "जब उसने मुँह खोला तो सब ने खिल्ली उड़ाई।", difficulty: "medium" },
        { id: 21, hindi: "गले का हार", meaning_hindi: "बहुत प्रिय, सबसे प्यारा", meaning_english: "Beloved, most dear", example: "लक्ष्मण राम के गले का हार थे।", difficulty: "medium" }
      ]
    },
    {
      name: "अन्य (Other)",
      emoji: "⭐",
      muhavare: [
        { id: 22, hindi: "पापड़ बेलना", meaning_hindi: "कड़ी मेहनत करना, कठिन परिस्थितियों में गुजारना", meaning_english: "Hard work, struggle", example: "आई.ए.एस. परीक्षा पास करने के लिए पापड़ बेलने पड़ते हैं।", difficulty: "easy" },
        { id: 23, hindi: "अंधे की लाठी", meaning_hindi: "एकमात्र सहारा, बहुत प्रिय व्यक्ति", meaning_english: "Only support, beloved", example: "बाप की मृत्यु के बाद श्याम ही माँ की अंधे की लाठी है।", difficulty: "easy" },
        { id: 24, hindi: "कमर टूटना", meaning_hindi: "बेसहारा होना, हार मान लेना", meaning_english: "Helpless, defeated", example: "जवान बेटे के मर जाने से बाप की कमर ही टूट गई।", difficulty: "medium" },
        { id: 25, hindi: "हिम्मत टूटना", meaning_hindi: "साहस समाप्त होना, डर के मारे", meaning_english: "Lose courage", example: "असफलता के कारण उसकी हिम्मत टूट गई।", difficulty: "medium" },
        { id: 26, hindi: "आँख दिखाना", meaning_hindi: "क्रोध प्रकट करना, धमकाना", meaning_english: "Show anger, threaten", example: "पिता ने बेटे को आँखें दिखाई।", difficulty: "medium" },
        { id: 27, hindi: "सोने पर सुहागा", meaning_hindi: "अच्छी चीज पर और अच्छाई का होना", meaning_english: "Enhancement, improvement", example: "पहले से सुंदर चेहरे पर अच्छा मेकअप सोने पर सुहागा है।", difficulty: "medium" },
        { id: 28, hindi: "त्रिशंकु की दशा", meaning_hindi: "न इधर का होना न उधर का, कशमकश में फँसना", meaning_english: "Dilemma, torn between two", example: "नौकरी न मिली, पढ़ाई भी छूट गई - उसकी त्रिशंकु दशा हो गई है।", difficulty: "hard" },
        { id: 29, hindi: "अंधे के हाथ बटेर", meaning_hindi: "अयोग्य को गुणवान वस्तु मिल जाना", meaning_english: "Unworthy person gets good fortune", example: "बिना मेहनत के नौकरी मिल गई - अंधे के हाथ बटेर लग गया।", difficulty: "hard" },
        { id: 30, hindi: "गुदड़ी का लाल", meaning_hindi: "गरीब के घर में योग्य/प्रतिभाशाली बेटा", meaning_english: "Talented child from poor family", example: "प्रेमचंद गुदड़ी के लाल थे - गरीब परिवार से आकर महान लेखक बने।", difficulty: "hard" },
        { id: 31, hindi: "दिवाला निकल जाना", meaning_hindi: "सब कुछ खो जाना, बर्बाद हो जाना", meaning_english: "Go bankrupt, ruined", example: "जुए की लत से उसका दिवाला निकल गया।", difficulty: "medium" },
        { id: 32, hindi: "काम आना", meaning_hindi: "शहीद होना, मारे जाना (सकारात्मक या नकारात्मक)", meaning_english: "Die for a cause, sacrifice", example: "स्वतंत्रता के लिए कई नेता काम आए।", difficulty: "hard" },
        { id: 33, hindi: "काम तमाम करना", meaning_hindi: "मार देना, खत्म कर देना", meaning_english: "Kill, finish off", example: "सेना के एक वार में आतंकियों का काम तमाम कर दिया।", difficulty: "hard" }
      ]
    }
  ]
};

const quizQuestions = [
  { id: 1, type: "meaning", hindi_text: "दाल न गलना", options: ["खाना पकाना", "कोई प्रभाव न पड़ना", "दाल बनाना", "खाना खराब होना"], correct: 1 },
  { id: 2, type: "reverse", meaning: "समझ में आ जाना", options: ["दाल न गलना", "आँखें खुल जाना", "हाथ आना", "मुँह खोलना"], correct: 1 },
  { id: 3, type: "fill_blank", sentence: "परीक्षा पास करने के लिए छात्रों को _______ पढ़ना होगा।", options: ["आँखें फोड़कर", "हाथ मिलाकर", "दिल लगाकर", "सिर झुकाकर"], correct: 0 },
  { id: 4, type: "meaning", hindi_text: "अंधे की लाठी", options: ["एक बूढ़े की लाठी", "एकमात्र सहारा", "अंधे को चलना सिखाना", "लाठी से अंधे को मारना"], correct: 1 },
  { id: 5, type: "meaning", hindi_text: "आँख का तारा", options: ["बहुत प्रिय व्यक्ति", "आँख में दर्द", "अंधा व्यक्ति", "नेत्र रोग"], correct: 0 },
  { id: 6, type: "reverse", meaning: "कड़ी मेहनत करना", options: ["हाथ मलना", "पापड़ बेलना", "दिल टूटना", "सिर चढ़ना"], correct: 1 },
  { id: 7, type: "meaning", hindi_text: "मुँह काला करना", options: ["मुँह धोना", "खाना खाना", "शर्मिंदगी होना", "बात करना"], correct: 2 },
  { id: 8, type: "fill_blank", sentence: "बेटे की सफलता से माता का _______ हो गया।", options: ["दिल टूट गया", "कलेजा ठंडा", "सिर चढ़ गया", "हाथ धो लिए"], correct: 1 },
  { id: 9, type: "meaning", hindi_text: "हाथ धोना", options: ["हाथ साफ करना", "पूरी तरह नाता तोड़ना", "मदद करना", "हाथ मिलाना"], correct: 1 },
  { id: 10, type: "reverse", meaning: "तैयार होना, संकल्पबद्ध होना", options: ["कमर टूटना", "कमर कसना", "सिर उठाना", "हाथ आना"], correct: 1 }
];

// State management
let appState = {
  learnedMuhavare: new Set(),
  favorites: new Set(),
  currentCategory: null,
  currentMuhavaraIndex: 0,
  quizScore: 0,
  currentQuestionIndex: 0,
  quizAnswered: false,
  practiceDifficulty: 'easy',
  practiceScore: 0
};

// Utility functions
function showScreen(screenId) {
  document.querySelectorAll('.screen').forEach(screen => {
    screen.classList.remove('active');
  });
  document.getElementById(screenId).classList.add('active');
  
  if (screenId === 'homeScreen') {
    updateStats();
  } else if (screenId === 'learnScreen') {
    showCategoryList();
  } else if (screenId === 'quizScreen') {
    startQuiz();
  } else if (screenId === 'practiceScreen') {
    showPracticeExercises();
  } else if (screenId === 'favoritesScreen') {
    showFavorites();
  }
}

function updateStats() {
  const totalMuhavare = muhavareData.categories.reduce((sum, cat) => sum + cat.muhavare.length, 0);
  const learnedCount = appState.learnedMuhavare.size;
  const readyToLearn = totalMuhavare - learnedCount;
  
  document.getElementById('totalMuhavare').textContent = totalMuhavare;
  document.getElementById('learnedCount').textContent = learnedCount;
  document.getElementById('readyToLearn').textContent = readyToLearn;
}

// Learn Mode
function showCategoryList() {
  const categoryList = document.getElementById('categoryList');
  const muhavaraViewer = document.getElementById('muhavaraViewer');
  
  categoryList.style.display = 'flex';
  muhavaraViewer.style.display = 'none';
  
  categoryList.innerHTML = muhavareData.categories.map(category => `
    <div class="category-card" onclick="selectCategory('${category.name}')">
      <div class="category-header">
        <div class="category-emoji">${category.emoji}</div>
        <div class="category-info">
          <h3>${category.name}</h3>
          <p class="category-count">${category.muhavare.length} मुहावरे</p>
        </div>
      </div>
    </div>
  `).join('');
}

function selectCategory(categoryName) {
  appState.currentCategory = muhavareData.categories.find(cat => cat.name === categoryName);
  appState.currentMuhavaraIndex = 0;
  showMuhavaraViewer();
}

function showMuhavaraViewer() {
  const categoryList = document.getElementById('categoryList');
  const muhavaraViewer = document.getElementById('muhavaraViewer');
  
  categoryList.style.display = 'none';
  muhavaraViewer.style.display = 'block';
  
  renderCurrentMuhavara();
}

function renderCurrentMuhavara() {
  const muhavara = appState.currentCategory.muhavare[appState.currentMuhavaraIndex];
  const isFavorite = appState.favorites.has(muhavara.id);
  const totalInCategory = appState.currentCategory.muhavare.length;
  
  const muhavaraViewer = document.getElementById('muhavaraViewer');
  muhavaraViewer.innerHTML = `
    <div class="navigation-buttons">
      <button class="nav-btn" onclick="previousMuhavara()" ${appState.currentMuhavaraIndex === 0 ? 'disabled' : ''}>⬅️ Previous</button>
      <div class="progress-info">
        ${appState.currentMuhavaraIndex + 1} / ${totalInCategory}
        <div class="progress-bar">
          <div class="progress-fill" style="width: ${((appState.currentMuhavaraIndex + 1) / totalInCategory) * 100}%"></div>
        </div>
      </div>
      <button class="nav-btn" onclick="nextMuhavara()" ${appState.currentMuhavaraIndex === totalInCategory - 1 ? 'disabled' : ''}>Next ➡️</button>
    </div>
    
    <div class="muhavara-viewer">
      <button class="favorite-btn" onclick="toggleFavorite(${muhavara.id})">
        ${isFavorite ? '⭐' : '☆'}
      </button>
      
      <h2 class="muhavara-title">${muhavara.hindi}</h2>
      
      <div class="meaning-section">
        <div class="meaning-label">हिंदी अर्थ</div>
        <p class="meaning-text">${muhavara.meaning_hindi}</p>
      </div>
      
      <div class="meaning-section">
        <div class="meaning-label">English Meaning</div>
        <p class="meaning-text">${muhavara.meaning_english}</p>
      </div>
      
      <div class="example-section">
        <div class="meaning-label">उदाहरण / Example</div>
        <p class="example-text">"${muhavara.example}"</p>
      </div>
    </div>
  `;
  
  // Mark as learned
  appState.learnedMuhavare.add(muhavara.id);
}

function previousMuhavara() {
  if (appState.currentMuhavaraIndex > 0) {
    appState.currentMuhavaraIndex--;
    renderCurrentMuhavara();
  }
}

function nextMuhavara() {
  if (appState.currentMuhavaraIndex < appState.currentCategory.muhavare.length - 1) {
    appState.currentMuhavaraIndex++;
    renderCurrentMuhavara();
  }
}

function toggleFavorite(muhavaraId) {
  if (appState.favorites.has(muhavaraId)) {
    appState.favorites.delete(muhavaraId);
  } else {
    appState.favorites.add(muhavaraId);
  }
  renderCurrentMuhavara();
}

// Quiz Mode
function startQuiz() {
  appState.quizScore = 0;
  appState.currentQuestionIndex = 0;
  appState.quizAnswered = false;
  renderQuizQuestion();
}

function renderQuizQuestion() {
  const quizContainer = document.getElementById('quizContainer');
  
  if (appState.currentQuestionIndex >= quizQuestions.length) {
    showQuizResults();
    return;
  }
  
  const question = quizQuestions[appState.currentQuestionIndex];
  let questionText = '';
  
  if (question.type === 'meaning') {
    questionText = `इस मुहावरे का अर्थ क्या है? <br><strong>${question.hindi_text}</strong>`;
  } else if (question.type === 'reverse') {
    questionText = `इस अर्थ का मुहावरा कौन सा है? <br><strong>${question.meaning}</strong>`;
  } else if (question.type === 'fill_blank') {
    questionText = `रिक्त स्थान भरें: <br><strong>${question.sentence}</strong>`;
  }
  
  quizContainer.innerHTML = `
    <div class="quiz-container">
      <div class="quiz-header">
        <div>Question ${appState.currentQuestionIndex + 1} / ${quizQuestions.length}</div>
        <div class="quiz-score">Score: ${appState.quizScore}</div>
      </div>
      
      <div class="quiz-question">${questionText}</div>
      
      <div class="quiz-options">
        ${question.options.map((option, index) => `
          <button class="quiz-option" onclick="checkAnswer(${index})" id="option${index}">
            ${option}
          </button>
        `).join('')}
      </div>
      
      <div id="quizFeedback"></div>
    </div>
  `;
}

function checkAnswer(selectedIndex) {
  if (appState.quizAnswered) return;
  
  const question = quizQuestions[appState.currentQuestionIndex];
  const isCorrect = selectedIndex === question.correct;
  
  appState.quizAnswered = true;
  
  const selectedOption = document.getElementById(`option${selectedIndex}`);
  const correctOption = document.getElementById(`option${question.correct}`);
  
  if (isCorrect) {
    selectedOption.classList.add('correct');
    appState.quizScore += 10;
    showFeedback('✅ Correct! Great job!', 'correct');
  } else {
    selectedOption.classList.add('incorrect');
    correctOption.classList.add('correct');
    showFeedback('❌ Incorrect! The correct answer is highlighted.', 'incorrect');
  }
  
  // Disable all options
  document.querySelectorAll('.quiz-option').forEach(opt => {
    opt.style.pointerEvents = 'none';
  });
  
  // Show next button
  const feedback = document.getElementById('quizFeedback');
  feedback.innerHTML += `<button class="next-question-btn" onclick="nextQuestion()">Next Question</button>`;
}

function showFeedback(message, type) {
  const feedback = document.getElementById('quizFeedback');
  feedback.innerHTML = `<div class="quiz-feedback ${type}">${message}</div>`;
}

function nextQuestion() {
  appState.currentQuestionIndex++;
  appState.quizAnswered = false;
  renderQuizQuestion();
}

function showQuizResults() {
  const percentage = Math.round((appState.quizScore / (quizQuestions.length * 10)) * 100);
  let message = '';
  
  if (percentage >= 90) {
    message = '🎉 Outstanding! You\'re a Muhavare Master!';
  } else if (percentage >= 70) {
    message = '👏 Great job! Keep practicing!';
  } else if (percentage >= 50) {
    message = '👍 Good effort! Review and try again!';
  } else {
    message = '💪 Keep learning! You\'ll get better!';
  }
  
  const quizContainer = document.getElementById('quizContainer');
  quizContainer.innerHTML = `
    <div class="quiz-result">
      <div class="result-score">🎯 ${appState.quizScore} / ${quizQuestions.length * 10}</div>
      <div class="result-percentage">${percentage}%</div>
      <div class="result-message">${message}</div>
      <button class="restart-btn" onclick="startQuiz()">🔄 Restart Quiz</button>
    </div>
  `;
}

// Practice Mode
function setPracticeDifficulty(difficulty) {
  appState.practiceDifficulty = difficulty;
  
  document.querySelectorAll('.difficulty-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  event.target.classList.add('active');
  
  showPracticeExercises();
}

function showPracticeExercises() {
  const practiceContent = document.getElementById('practiceContent');
  
  // Get all muhavare flattened
  const allMuhavare = [];
  muhavareData.categories.forEach(category => {
    category.muhavare.forEach(m => allMuhavare.push(m));
  });
  
  // Filter by difficulty
  let filteredMuhavare = allMuhavare;
  if (appState.practiceDifficulty === 'easy') {
    filteredMuhavare = allMuhavare.filter(m => m.difficulty === 'easy').slice(0, 20);
  } else if (appState.practiceDifficulty === 'medium') {
    filteredMuhavare = allMuhavare.filter(m => m.difficulty === 'easy' || m.difficulty === 'medium');
  }
  
  // Create fill-in-blank exercise
  const randomMuhavara = filteredMuhavare[Math.floor(Math.random() * filteredMuhavare.length)];
  
  practiceContent.innerHTML = `
    <div class="practice-exercise">
      <h3 class="exercise-title">📝 Fill in the Blank</h3>
      <p class="exercise-question">Complete the sentence with the correct muhavara:</p>
      <p class="exercise-question"><strong>${randomMuhavara.example.replace(randomMuhavara.hindi, '______')}</strong></p>
      <input type="text" class="practice-input" id="practiceAnswer" placeholder="यहाँ मुहावरा लिखें...">
      <button class="check-answer-btn" onclick="checkPracticeAnswer('${randomMuhavara.hindi}')">Check Answer</button>
      <div id="practiceResult"></div>
    </div>
    
    <div class="practice-exercise" style="margin-top: 32px;">
      <h3 class="exercise-title">🎯 Matching Exercise</h3>
      <p class="exercise-question">Match the muhavara to its meaning (Click two items to match):</p>
      <div id="matchingGame"></div>
    </div>
  `;
  
  createMatchingGame(filteredMuhavare);
}

function checkPracticeAnswer(correctAnswer) {
  const userAnswer = document.getElementById('practiceAnswer').value.trim();
  const resultDiv = document.getElementById('practiceResult');
  
  if (userAnswer === correctAnswer) {
    resultDiv.innerHTML = '<div class="quiz-feedback correct">✅ Perfect! You got it right!</div>';
  } else {
    resultDiv.innerHTML = `<div class="quiz-feedback incorrect">❌ Not quite. The correct answer is: <strong>${correctAnswer}</strong></div>`;
  }
}

let matchingGameState = {
  selected: [],
  matched: new Set()
};

function createMatchingGame(muhavare) {
  const matchingDiv = document.getElementById('matchingGame');
  const gameMuhavare = muhavare.slice(0, 4);
  
  const muhavareItems = gameMuhavare.map((m, i) => `
    <div class="matching-item" data-id="${i}" data-type="muhavara" onclick="selectMatchingItem(${i}, 'muhavara')">
      ${m.hindi}
    </div>
  `);
  
  const meaningItems = gameMuhavare.map((m, i) => `
    <div class="matching-item" data-id="${i}" data-type="meaning" onclick="selectMatchingItem(${i}, 'meaning')">
      ${m.meaning_hindi}
    </div>
  `);
  
  matchingDiv.innerHTML = `
    <div class="matching-exercise">
      <div class="matching-column">${muhavareItems.join('')}</div>
      <div class="matching-column">${meaningItems.join('')}</div>
    </div>
  `;
}

function selectMatchingItem(id, type) {
  if (matchingGameState.matched.has(`${id}-${type}`)) return;
  
  const item = event.target;
  
  if (matchingGameState.selected.length === 0) {
    matchingGameState.selected.push({ id, type, element: item });
    item.classList.add('selected');
  } else if (matchingGameState.selected.length === 1) {
    const first = matchingGameState.selected[0];
    
    if (first.type === type) {
      // Same type selected, replace selection
      first.element.classList.remove('selected');
      matchingGameState.selected = [{ id, type, element: item }];
      item.classList.add('selected');
    } else {
      // Different types, check match
      if (first.id === id) {
        // Correct match!
        item.classList.add('selected');
        matchingGameState.matched.add(`${id}-muhavara`);
        matchingGameState.matched.add(`${id}-meaning`);
        
        setTimeout(() => {
          first.element.style.opacity = '0.3';
          item.style.opacity = '0.3';
          first.element.style.pointerEvents = 'none';
          item.style.pointerEvents = 'none';
        }, 500);
      } else {
        // Wrong match
        item.classList.add('selected');
        setTimeout(() => {
          first.element.classList.remove('selected');
          item.classList.remove('selected');
        }, 1000);
      }
      
      matchingGameState.selected = [];
    }
  }
}

// Favorites
function showFavorites() {
  const favoritesList = document.getElementById('favoritesList');
  
  if (appState.favorites.size === 0) {
    favoritesList.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">⭐</div>
        <div class="empty-message">No favorites yet!</div>
        <p>Star muhavare in Learn Mode to add them here.</p>
      </div>
    `;
    return;
  }
  
  // Get all muhavare
  const allMuhavare = [];
  muhavareData.categories.forEach(category => {
    category.muhavare.forEach(m => allMuhavare.push(m));
  });
  
  const favoriteMuhavare = allMuhavare.filter(m => appState.favorites.has(m.id));
  
  favoritesList.innerHTML = `
    <div class="favorites-list">
      ${favoriteMuhavare.map(m => `
        <div class="favorite-item">
          <div class="favorite-muhavara">${m.hindi}</div>
          <div class="favorite-meaning"><strong>हिंदी:</strong> ${m.meaning_hindi}</div>
          <div class="favorite-meaning"><strong>English:</strong> ${m.meaning_english}</div>
          <div class="favorite-meaning" style="font-style: italic; margin-top: 8px;">"${m.example}"</div>
        </div>
      `).join('')}
    </div>
  `;
}

// Initialize app
window.addEventListener('DOMContentLoaded', () => {
  updateStats();
});